<div class="wrap">

	<h2>About the PHP-KeyCodes plugin</h2>
	<p>This plugin is used to sell pin codes, key codes, software licence codes using PayPal IPN system.</p>        
        
</div>