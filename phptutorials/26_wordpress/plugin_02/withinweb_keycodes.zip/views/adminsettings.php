<div class="wrap">
        
	<h2>Settings for the PHP-KeyCodes plugin</h2>
	<p>This page provides you with the set up that is required to use the KeyCodes system.</p>     

</div>